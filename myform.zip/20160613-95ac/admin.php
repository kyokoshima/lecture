<?php
require_once( dirname(__FILE__).'/form.lib.php' );

define( 'PHPFMG_USER', "k.yokoshima@gmail.com" ); // must be a email address. for sending password to you.
define( 'PHPFMG_PW', "954df0" );

?>
<?php
/**
 * GNU Library or Lesser General Public License version 2.0 (LGPLv2)
*/

# main
# ------------------------------------------------------
error_reporting( E_ERROR ) ;
phpfmg_admin_main();
# ------------------------------------------------------




function phpfmg_admin_main(){
    $mod  = isset($_REQUEST['mod'])  ? $_REQUEST['mod']  : '';
    $func = isset($_REQUEST['func']) ? $_REQUEST['func'] : '';
    $function = "phpfmg_{$mod}_{$func}";
    if( !function_exists($function) ){
        phpfmg_admin_default();
        exit;
    };

    // no login required modules
    $public_modules   = false !== strpos('|captcha|', "|{$mod}|", "|ajax|");
    $public_functions = false !== strpos('|phpfmg_ajax_submit||phpfmg_mail_request_password||phpfmg_filman_download||phpfmg_image_processing||phpfmg_dd_lookup|', "|{$function}|") ;   
    if( $public_modules || $public_functions ) { 
        $function();
        exit;
    };
    
    return phpfmg_user_isLogin() ? $function() : phpfmg_admin_default();
}

function phpfmg_ajax_submit(){
    $phpfmg_send = phpfmg_sendmail( $GLOBALS['form_mail'] );
    $isHideForm  = isset($phpfmg_send['isHideForm']) ? $phpfmg_send['isHideForm'] : false;

    $response = array(
        'ok' => $isHideForm,
        'error_fields' => isset($phpfmg_send['error']) ? $phpfmg_send['error']['fields'] : '',
        'OneEntry' => isset($GLOBALS['OneEntry']) ? $GLOBALS['OneEntry'] : '',
    );
    
    @header("Content-Type:text/html; charset=$charset");
    echo "<html><body><script>
    var response = " . json_encode( $response ) . ";
    try{
        parent.fmgHandler.onResponse( response );
    }catch(E){};
    \n\n";
    echo "\n\n</script></body></html>";

}


function phpfmg_admin_default(){
    if( phpfmg_user_login() ){
        phpfmg_admin_panel();
    };
}



function phpfmg_admin_panel()
{    
    phpfmg_admin_header();
    phpfmg_writable_check();
?>    
<table cellpadding="0" cellspacing="0" border="0">
	<tr>
		<td valign=top style="padding-left:280px;">

<style type="text/css">
    .fmg_title{
        font-size: 16px;
        font-weight: bold;
        padding: 10px;
    }
    
    .fmg_sep{
        width:32px;
    }
    
    .fmg_text{
        line-height: 150%;
        vertical-align: top;
        padding-left:28px;
    }

</style>

<script type="text/javascript">
    function deleteAll(n){
        if( confirm("Are you sure you want to delete?" ) ){
            location.href = "admin.php?mod=log&func=delete&file=" + n ;
        };
        return false ;
    }
</script>


<div class="fmg_title">
    1. Email Traffics
</div>
<div class="fmg_text">
    <a href="admin.php?mod=log&func=view&file=1">view</a> &nbsp;&nbsp;
    <a href="admin.php?mod=log&func=download&file=1">download</a> &nbsp;&nbsp;
    <?php 
        if( file_exists(PHPFMG_EMAILS_LOGFILE) ){
            echo '<a href="#" onclick="return deleteAll(1);">delete all</a>';
        };
    ?>
</div>


<div class="fmg_title">
    2. Form Data
</div>
<div class="fmg_text">
    <a href="admin.php?mod=log&func=view&file=2">view</a> &nbsp;&nbsp;
    <a href="admin.php?mod=log&func=download&file=2">download</a> &nbsp;&nbsp;
    <?php 
        if( file_exists(PHPFMG_SAVE_FILE) ){
            echo '<a href="#" onclick="return deleteAll(2);">delete all</a>';
        };
    ?>
</div>

<div class="fmg_title">
    3. Form Generator
</div>
<div class="fmg_text">
    <a href="http://www.formmail-maker.com/generator.php" onclick="document.frmFormMail.submit(); return false;" title="<?php echo htmlspecialchars(PHPFMG_SUBJECT);?>">Edit Form</a> &nbsp;&nbsp;
    <a href="http://www.formmail-maker.com/generator.php" >New Form</a>
</div>
    <form name="frmFormMail" action='http://www.formmail-maker.com/generator.php' method='post' enctype='multipart/form-data'>
    <input type="hidden" name="uuid" value="<?php echo PHPFMG_ID; ?>">
    <input type="hidden" name="external_ini" value="<?php echo function_exists('phpfmg_formini') ?  phpfmg_formini() : ""; ?>">
    </form>

		</td>
	</tr>
</table>

<?php
    phpfmg_admin_footer();
}



function phpfmg_admin_header( $title = '' ){
    header( "Content-Type: text/html; charset=" . PHPFMG_CHARSET );
?>
<html>
<head>
    <title><?php echo '' == $title ? '' : $title . ' | ' ; ?>PHP FormMail Admin Panel </title>
    <meta name="keywords" content="PHP FormMail Generator, PHP HTML form, send html email with attachment, PHP web form,  Free Form, Form Builder, Form Creator, phpFormMailGen, Customized Web Forms, phpFormMailGenerator,formmail.php, formmail.pl, formMail Generator, ASP Formmail, ASP form, PHP Form, Generator, phpFormGen, phpFormGenerator, anti-spam, web hosting">
    <meta name="description" content="PHP formMail Generator - A tool to ceate ready-to-use web forms in a flash. Validating form with CAPTCHA security image, send html email with attachments, send auto response email copy, log email traffics, save and download form data in Excel. ">
    <meta name="generator" content="PHP Mail Form Generator, phpfmg.sourceforge.net">

    <style type='text/css'>
    body, td, label, div, span{
        font-family : Verdana, Arial, Helvetica, sans-serif;
        font-size : 12px;
    }
    </style>
</head>
<body  marginheight="0" marginwidth="0" leftmargin="0" topmargin="0">

<table cellspacing=0 cellpadding=0 border=0 width="100%">
    <td nowrap align=center style="background-color:#024e7b;padding:10px;font-size:18px;color:#ffffff;font-weight:bold;width:250px;" >
        Form Admin Panel
    </td>
    <td style="padding-left:30px;background-color:#86BC1B;width:100%;font-weight:bold;" >
        &nbsp;
<?php
    if( phpfmg_user_isLogin() ){
        echo '<a href="admin.php" style="color:#ffffff;">Main Menu</a> &nbsp;&nbsp;' ;
        echo '<a href="admin.php?mod=user&func=logout" style="color:#ffffff;">Logout</a>' ;
    }; 
?>
    </td>
</table>

<div style="padding-top:28px;">

<?php
    
}


function phpfmg_admin_footer(){
?>

</div>

<div style="color:#cccccc;text-decoration:none;padding:18px;font-weight:bold;">
	:: <a href="http://phpfmg.sourceforge.net" target="_blank" title="Free Mailform Maker: Create read-to-use Web Forms in a flash. Including validating form with CAPTCHA security image, send html email with attachments, send auto response email copy, log email traffics, save and download form data in Excel. " style="color:#cccccc;font-weight:bold;text-decoration:none;">PHP FormMail Generator</a> ::
</div>

</body>
</html>
<?php
}


function phpfmg_image_processing(){
    $img = new phpfmgImage();
    $img->out_processing_gif();
}


# phpfmg module : captcha
# ------------------------------------------------------
function phpfmg_captcha_get(){
    $img = new phpfmgImage();
    $img->out();
    //$_SESSION[PHPFMG_ID.'fmgCaptchCode'] = $img->text ;
    $_SESSION[ phpfmg_captcha_name() ] = $img->text ;
}



function phpfmg_captcha_generate_images(){
    for( $i = 0; $i < 50; $i ++ ){
        $file = "$i.png";
        $img = new phpfmgImage();
        $img->out($file);
        $data = base64_encode( file_get_contents($file) );
        echo "'{$img->text}' => '{$data}',\n" ;
        unlink( $file );
    };
}


function phpfmg_dd_lookup(){
    $paraOk = ( isset($_REQUEST['n']) && isset($_REQUEST['lookup']) && isset($_REQUEST['field_name']) );
    if( !$paraOk )
        return;
        
    $base64 = phpfmg_dependent_dropdown_data();
    $data = @unserialize( base64_decode($base64) );
    if( !is_array($data) ){
        return ;
    };
    
    
    foreach( $data as $field ){
        if( $field['name'] == $_REQUEST['field_name'] ){
            $nColumn = intval($_REQUEST['n']);
            $lookup  = $_REQUEST['lookup']; // $lookup is an array
            $dd      = new DependantDropdown(); 
            echo $dd->lookupFieldColumn( $field, $nColumn, $lookup );
            return;
        };
    };
    
    return;
}


function phpfmg_filman_download(){
    if( !isset($_REQUEST['filelink']) )
        return ;
        
    $info =  @unserialize(base64_decode($_REQUEST['filelink']));
    if( !isset($info['recordID']) ){
        return ;
    };
    
    $file = PHPFMG_SAVE_ATTACHMENTS_DIR . $info['recordID'] . '-' . $info['filename'];
    phpfmg_util_download( $file, $info['filename'] );
}


class phpfmgDataManager
{
    var $dataFile = '';
    var $columns = '';
    var $records = '';
    
    function phpfmgDataManager(){
        $this->dataFile = PHPFMG_SAVE_FILE; 
    }
    
    function parseFile(){
        $fp = @fopen($this->dataFile, 'rb');
        if( !$fp ) return false;
        
        $i = 0 ;
        $phpExitLine = 1; // first line is php code
        $colsLine = 2 ; // second line is column headers
        $this->columns = array();
        $this->records = array();
        $sep = chr(0x09);
        while( !feof($fp) ) { 
            $line = fgets($fp);
            $line = trim($line);
            if( empty($line) ) continue;
            $line = $this->line2display($line);
            $i ++ ;
            switch( $i ){
                case $phpExitLine:
                    continue;
                    break;
                case $colsLine :
                    $this->columns = explode($sep,$line);
                    break;
                default:
                    $this->records[] = explode( $sep, phpfmg_data2record( $line, false ) );
            };
        }; 
        fclose ($fp);
    }
    
    function displayRecords(){
        $this->parseFile();
        echo "<table border=1 style='width=95%;border-collapse: collapse;border-color:#cccccc;' >";
        echo "<tr><td>&nbsp;</td><td><b>" . join( "</b></td><td>&nbsp;<b>", $this->columns ) . "</b></td></tr>\n";
        $i = 1;
        foreach( $this->records as $r ){
            echo "<tr><td align=right>{$i}&nbsp;</td><td>" . join( "</td><td>&nbsp;", $r ) . "</td></tr>\n";
            $i++;
        };
        echo "</table>\n";
    }
    
    function line2display( $line ){
        $line = str_replace( array('"' . chr(0x09) . '"', '""'),  array(chr(0x09),'"'),  $line );
        $line = substr( $line, 1, -1 ); // chop first " and last "
        return $line;
    }
    
}
# end of class



# ------------------------------------------------------
class phpfmgImage
{
    var $im = null;
    var $width = 73 ;
    var $height = 33 ;
    var $text = '' ; 
    var $line_distance = 8;
    var $text_len = 4 ;

    function phpfmgImage( $text = '', $len = 4 ){
        $this->text_len = $len ;
        $this->text = '' == $text ? $this->uniqid( $this->text_len ) : $text ;
        $this->text = strtoupper( substr( $this->text, 0, $this->text_len ) );
    }
    
    function create(){
        $this->im = imagecreate( $this->width, $this->height );
        $bgcolor   = imagecolorallocate($this->im, 255, 255, 255);
        $textcolor = imagecolorallocate($this->im, 0, 0, 0);
        $this->drawLines();
        imagestring($this->im, 5, 20, 9, $this->text, $textcolor);
    }
    
    function drawLines(){
        $linecolor = imagecolorallocate($this->im, 210, 210, 210);
    
        //vertical lines
        for($x = 0; $x < $this->width; $x += $this->line_distance) {
          imageline($this->im, $x, 0, $x, $this->height, $linecolor);
        };
    
        //horizontal lines
        for($y = 0; $y < $this->height; $y += $this->line_distance) {
          imageline($this->im, 0, $y, $this->width, $y, $linecolor);
        };
    }
    
    function out( $filename = '' ){
        if( function_exists('imageline') ){
            $this->create();
            if( '' == $filename ) header("Content-type: image/png");
            ( '' == $filename ) ? imagepng( $this->im ) : imagepng( $this->im, $filename );
            imagedestroy( $this->im ); 
        }else{
            $this->out_predefined_image(); 
        };
    }

    function uniqid( $len = 0 ){
        $md5 = md5( uniqid(rand()) );
        return $len > 0 ? substr($md5,0,$len) : $md5 ;
    }
    
    function out_predefined_image(){
        header("Content-type: image/png");
        $data = $this->getImage(); 
        echo base64_decode($data);
    }
    
    // Use predefined captcha random images if web server doens't have GD graphics library installed  
    function getImage(){
        $images = array(
			'E2B8' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAZklEQVR4nGNYhQEaGAYTpIn7QkMYQ1hDGaY6IIkFNLC2sjY6BASgiIk0ujYEOoigiDE0uiLUgZ0UGrVq6dLQVVOzkNwHlJ+CaR5DACuGeYwOmGKsDeh6Q0NEQ13R3DxQ4UdFiMV9ALXYzis4jbWVAAAAAElFTkSuQmCC',
			'4328' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAdUlEQVR4nGNYhQEaGAYTpI37prCGMIQyTHVAFgsRaWV0dAgIQBJjDGFodG0IdBBBEmOdwtDK0BAAUwd20rRpq8JWrcyamoXkvgCQulYGFPNCQxkaHaYwopjHMAUoFoAuBnSLA6pekJtZQwNQ3TxQ4Uc9iMV9AD+6y31erTRZAAAAAElFTkSuQmCC',
			'8C96' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAZElEQVR4nGNYhQEaGAYTpIn7WAMYQxlCGaY6IImJTGFtdHR0CAhAEgtoFWlwbQh0EEBRJ9LAChRDdt/SqGmrVmZGpmYhuQ+kjiEkEMM8BqBeETQxRzQxbG7B5uaBCj8qQizuAwCVisyN8qoAGAAAAABJRU5ErkJggg==',
			'88AE' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAYUlEQVR4nGNYhQEaGAYTpIn7WAMYQximMIYGIImJTGFtZQhldEBWF9Aq0ujo6IgiBlLH2hAIEwM7aWnUyrClqyJDs5Dch6YObp5rKBYxNHXY9ILcDBRDcfNAhR8VIRb3AQCBccsb+bMbewAAAABJRU5ErkJggg==',
			'BB58' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAaUlEQVR4nGNYhQEaGAYTpIn7QgNEQ1hDHaY6IIkFTBFpZW1gCAhAFmsVaXRtYHQQQVc3Fa4O7KTQqKlhSzOzpmYhuQ+kDkhimOfQEIhqHtiOQAw7GB0dUPSC3MwQyoDi5oEKPypCLO4DAJLnzh20mA0WAAAAAElFTkSuQmCC',
			'F2C6' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAbUlEQVR4nGNYhQEaGAYTpIn7QkMZQxhCHaY6IIkFNLC2MjoEBASgiIk0ujYIOgigiDEAxRgdkN0XGrVq6dJVK1OzkNwHVDeFtYERzTyGAKCYgwiKGKMDK9AOVDGQKnS3iIY6oLl5oMKPihCL+wDzLszPS9WFwwAAAABJRU5ErkJggg==',
			'AA2A' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAcklEQVR4nGNYhQEaGAYTpIn7GB0YAhhCGVqRxVgDGEMYHR2mOiCJiUxhbWVtCAgIQBILaBVpdGgIdBBBcl/U0mkrs1ZmZk1Dch9YXSsjTB0YhoaKhjpMYQwNQTcvAFUdSMzRAVPMNTQQRWygwo+KEIv7AMvRzDUehUjrAAAAAElFTkSuQmCC',
			'0FC9' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAYklEQVR4nGNYhQEaGAYTpIn7GB1EQx1CHaY6IImxBogAxQMCApDERKaINLA2CDqIIIkFtILEGGFiYCdFLZ0athRIhSG5D6KOYSqmXqC5GHYIoNiBzS1gG9HcPFDhR0WIxX0ACsTLTdiBEC8AAAAASUVORK5CYII=',
			'5B54' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAd0lEQVR4nGNYhQEaGAYTpIn7QkNEQ1hDHRoCkMQCGkRaWRsYGtHEGl0bGFqRxQIDgOqmMkwJQHJf2LSpYUszs6KikN3XKtIKVO2ArBco1ujQEBgagmxHK8iOABS3iEwRaWV0RHUfa4BoCEMoA4rYQIUfFSEW9wEA/gXOWPiQpB4AAAAASUVORK5CYII=',
			'4B2C' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAdElEQVR4nGNYhQEaGAYTpI37poiGMIQyTA1AFgsRaWV0dAgQQRJjDBFpdG0IdGBBEmOdItLKABRDdt+0aVPDVq3MzEJ2XwBIXSujA7K9oaEijQ5TUMUYpgDFAhhR7ACKgXSiuAXkZtbQAFQ3D1T4UQ9icR8ARnLKtoiwN1YAAAAASUVORK5CYII=',
			'4DD7' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAZklEQVR4nGNYhQEaGAYTpI37poiGsIYyhoYgi4WItLI2OjSIIIkxhog0ujYEoIixToGIBSC5b9q0aStTV0WtzEJyXwBEXSuyvaGhYLEpqG4BiwWgiQHd4uiAxc2oYgMVftSDWNwHAOuazXXaJQjRAAAAAElFTkSuQmCC',
			'D13C' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAY0lEQVR4nGNYhQEaGAYTpIn7QgMYAhhDGaYGIIkFTGEMYG10CBBBFmtlDWBoCHRgQRFjCGBodHRAdl/U0lVRq6auzEJ2H5o6hBjQPGxiKHZMYcBwS2gAayi6mwcq/KgIsbgPAD8Wy25atOYMAAAAAElFTkSuQmCC',
			'0FC2' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAZElEQVR4nGNYhQEaGAYTpIn7GB1EQx1CHaY6IImxBogAxQMCApDERKaINLA2CDqIIIkFtILEgHJI7otaOjVsKYhGch9UXaMDpt5WBgw7BKYwYHELqpuBNoY6hoYMgvCjIsTiPgCnD8uus/HmpQAAAABJRU5ErkJggg==',
			'68D4' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAZ0lEQVR4nGNYhQEaGAYTpIn7WAMYQ1hDGRoCkMREprC2sjY6NCKLBbSINLo2BLSiiDUA1TUETAlAcl9k1MqwpauioqKQ3BcCMq8h0AFFbyvIvMDQEAyxAGxuQRHD5uaBCj8qQizuAwD2Ys9JJlBfcAAAAABJRU5ErkJggg==',
			'0022' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAcklEQVR4nGNYhQEaGAYTpIn7GB0YAhhCGaY6IImxBjCGMDo6BAQgiYlMYW1lbQh0EEESC2gVaXRoCGgQQXJf1NJpK7NWZq2KQnIfWF0rQ6MDut4pDK0MaHYAXTOFAd0tIDeiuZk1NDA0ZBCEHxUhFvcBALNCyuQBAr9XAAAAAElFTkSuQmCC',
			'42D1' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAbElEQVR4nGNYhQEaGAYTpI37pjCGsIYytKKIhbC2sjY6TEUWYwwRaXRtCAhFFmOdwgASg+kFO2natFVLl66KWorsvoApDFNYEerAMDSUIQBdDOgWB0wx1gagW9DERENdQxlCAwZD+FEPYnEfALjnzL1qhZCGAAAAAElFTkSuQmCC',
			'170B' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAa0lEQVR4nGNYhQEaGAYTpIn7GB1EQx2mMIY6IImxOjA0OoQyOgQgiYkCxRwdHR1EUPQytLI2BMLUgZ20MmvVtKWrIkOzkNwHVBeApA4qxugAEkM1j7WBEcMOIA/dLSFAMTQ3D1T4URFicR8AYV/IQc/A8ggAAAAASUVORK5CYII=',
			'DC74' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAZUlEQVR4nGNYhQEaGAYTpIn7QgMYQ1lDAxoCkMQCprA2OjQENKKItYo0AMVa0cUYGh2mBCC5L2rptFWrlq6KikJyH1jdFEYHDL1Au0PQxBwdGDDc4tqAKgZ2M5rYQIUfFSEW9wEAohDQTe4X/QQAAAAASUVORK5CYII=',
			'CDEF' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAVUlEQVR4nGNYhQEaGAYTpIn7WENEQ1hDHUNDkMREWkVaWRsYHZDVBTSKNLqiizWgiIGdFLVq2srU0JWhWUjuQ1OHWwyLHdjcAnUzithAhR8VIRb3AQAPPMpcQfffiAAAAABJRU5ErkJggg==',
			'9FBC' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAYElEQVR4nGNYhQEaGAYTpIn7WANEQ11DGaYGIImJTBFpYG10CBBBEgtoBYo1BDqwoIs1Ojogu2/a1KlhS0NXZiG7j9UVRR0EQs1DFhPAYgc2t7ACeaxobh6o8KMixOI+AIowy5SjCPgtAAAAAElFTkSuQmCC',
			'58C7' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAb0lEQVR4nGNYhQEaGAYTpIn7QkMYQxhCHUNDkMQCGlhbGR0CGkRQxEQaXRsEUMQCA1hbWcFyCPeFTVsZtnTVqpVZyO5rBatrRbG5FWQewxRksQCwmEAAspjIFJBbAh2QxVgDwG5GERuo8KMixOI+AE3Cy+vE5fcLAAAAAElFTkSuQmCC',
			'BDF2' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAZElEQVR4nGNYhQEaGAYTpIn7QgNEQ1hDA6Y6IIkFTBFpZW1gCAhAFmsVaXRtYHQQQVUHFGNoEEFyX2jUtJWpoatWRSG5D6qu0QHDPIZWBkyxKQxY3ILh5gbG0JBBEH5UhFjcBwDLWM4r2JIq4QAAAABJRU5ErkJggg==',
			'6165' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAcklEQVR4nGNYhQEaGAYTpIn7WAMYAhhCGUMDkMREpjAGMDo6OiCrC2hhDWBtQBNrYACKMbo6ILkvMmpV1NKpK6OikNwXMgWoztGhQQRZbytIbwAWsUAHERS3MADd4hCA7D6gS0IZQhmmOgyC8KMixOI+AHlnyXFMBDSZAAAAAElFTkSuQmCC',
			'C566' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAcElEQVR4nGNYhQEaGAYTpIn7WENEQxlCGaY6IImJtIo0MDo6BAQgiQU0ijSwNjg6CCCLNYiEsDYwOiC7L2rV1KVLp65MzUJyH9CcRldHR1TzQGINgQ4iqHZgiIm0sraiu4U1hDEE3c0DFX5UhFjcBwA24sxQ6D2upgAAAABJRU5ErkJggg==',
			'D5BA' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAb0lEQVR4nGNYhQEaGAYTpIn7QgNEQ1lDGVqRxQKmiDSwNjpMdUAWawWKNQQEBKCKhbA2OjqIILkvaunUpUtDV2ZNQ3JfQCtDoytCHUKsITA0BNU8kBiquimsraxoekMDGENYQxlRxAYq/KgIsbgPANIzzipxg4djAAAAAElFTkSuQmCC',
			'1319' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAbUlEQVR4nGNYhQEaGAYTpIn7GB1YQximMEx1QBJjdRBpZQhhCAhAEhN1YGh0DGF0EEHRy9DKMAUuBnbSyqxVYaumrYoKQ3IfRB3DVDS9jQ5TGBqwiKHZIQLSi+qWENYQxlAHFDcPVPhREWJxHwBk28iO1AHnWgAAAABJRU5ErkJggg==',
			'4B8F' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAXElEQVR4nGNYhQEaGAYTpI37poiGMIQyhoYgi4WItDI6Ojogq2MMEWl0bQhEEWOdgqIO7KRp06aGrQpdGZqF5L6AKZjmhYZimscwBasYhl6om1HFBir8qAexuA8AymLJgXP2XzwAAAAASUVORK5CYII=',
			'38C3' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAXUlEQVR4nGNYhQEaGAYTpIn7RAMYQxhCHUIdkMQCprC2MjoEOgQgq2wVaXRtEGgQQRYDqmMFqUdy38qolWFLV61amoXsPlR1SOYxoJqHxQ5sbsHm5oEKPypCLO4DALAazJyPr02UAAAAAElFTkSuQmCC',
			'3531' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAa0lEQVR4nGNYhQEaGAYTpIn7RANEQxlDGVqRxQKmiDSwNjpMRVHZKgKSCUURmyISwtDoANMLdtLKqKlLV01dtRTFfVOAqhDqoOYBxRoC0MREMMQCprC2sqLpFQ1gDAG6OTRgEIQfFSEW9wEAKHDNEGOyJUcAAAAASUVORK5CYII=',
			'AB16' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAb0lEQVR4nGNYhQEaGAYTpIn7GB1EQximMEx1QBJjDRBpZQhhCAhAEhOZItLoGMLoIIAkFtAKVDeF0QHZfVFLp4atmrYyNQvJfVB1KOaFhoo0OgD1iqCah00MqBfVLQGtoiGMoQ4obh6o8KMixOI+AKnAzDFkvRBLAAAAAElFTkSuQmCC',
			'9B14' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAbklEQVR4nGNYhQEaGAYTpIn7WANEQximMDQEIImJTBFpZQhhaEQWC2gVaXQMYWhFE2sF6p0SgOS+aVOnhq2atioqCsl9rK4gdYwOyHoZgOY5TGEMDUESEwCLYXELmhjIzYyhDihiAxV+VIRY3AcAujfNeA1/NCsAAAAASUVORK5CYII=',
			'D157' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAZElEQVR4nGNYhQEaGAYTpIn7QgMYAlhDHUNDkMQCpjAGsAJpEWSxVlYsYkC9U4E0kvuilgJRZtbKLCT3gdSBSTS9IJvQxVgbAgJQxKYwBDA6Ojqgupk1lCGUEUVsoMKPihCL+wAQj8sLhzo/IQAAAABJRU5ErkJggg==',
			'0162' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAbElEQVR4nGNYhQEaGAYTpIn7GB0YAhhCGaY6IImxBjAGMDo6BAQgiYlMYQ1gbXB0EEESC2hlAIoB5ZDcF7UUiKYCaST3gdU5OjQ6YOgFkih2gMWmMKC4hQHsFlQ3s4YyhDKGhgyC8KMixOI+ALxUyWsdfx58AAAAAElFTkSuQmCC',
			'6341' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAZklEQVR4nGNYhQEaGAYTpIn7WANYQxgaHVqRxUSmiLQytDpMRRYLaAGqmuoQiiLWwNDKEAjXC3ZSZNSqsJWZWUuR3RcyhaGVFc2OgFaGRtfQAAwxB2xuQRODujk0YBCEHxUhFvcBAKZVzXYN1t1VAAAAAElFTkSuQmCC',
			'EC39' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAXklEQVR4nGNYhQEaGAYTpIn7QkMYQxlDGaY6IIkFNLA2ujY6BASgiIk0ODQEOoigiTE0OsLEwE4KjZq2atXUVVFhSO6DqHOYiqEXSqLaEYBmB6ZbsLl5oMKPihCL+wBTWM7AT+he4AAAAABJRU5ErkJggg==',
			'2BC4' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAb0lEQVR4nGNYhQEaGAYTpIn7WANEQxhCHRoCkMREpoi0MjoENCKLBbSKNLo2CLQiizG0irSyNjBMCUB237SpYUtXrYqKQnZfAEgd0EQkvYwOIPMYQ0OQ3dIAtgPVLQ1gt6CIhYZiunmgwo+KEIv7ANvtzY0qh3MHAAAAAElFTkSuQmCC',
			'4B10' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAbklEQVR4nGNYhQEaGAYTpI37poiGMExhaEURCxFpZQhhmOqAJMYYItLoGMIQEIAkxjoFqG4Ko4MIkvumTZsatmrayqxpSO4LQFUHhqGhIo0OaGIMU0BiqHYwgPWiugXkZsZQB1Q3D1T4UQ9icR8AaM3Lyrvh9LsAAAAASUVORK5CYII=',
			'D868' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAXklEQVR4nGNYhQEaGAYTpIn7QgMYQxhCGaY6IIkFTGFtZXR0CAhAFmsVaXRtcHQQQRFjbWVtYICpAzspaunKsKVTV03NQnIfWB1W8wLRzMMihsUt2Nw8UOFHRYjFfQBydc4J4QRu7QAAAABJRU5ErkJggg==',
			'AE3F' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAXElEQVR4nGNYhQEaGAYTpIn7GB1EQxmBMARJjDVApIG10dEBWZ3IFBEgGYgiFtAKFEOoAzspaunUsFVTV4ZmIbkPTR0YhobiMA+LGLpbAlrBbkYRG6jwoyLE4j4AEaPKqcU4GC4AAAAASUVORK5CYII=',
			'B72C' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAcElEQVR4nGNYhQEaGAYTpIn7QgNEQx1CGaYGIIkFTGFodHR0CBBBFmtlaHRtCHRgQVXXygAUQ3ZfaNSqaatWZmYhuw+oLoChldGBAcU8IH8KuhhrA0MAI5odIg1AVShuCQXyWEMDUNw8UOFHRYjFfQA8PcwBtVEeKQAAAABJRU5ErkJggg==',
			'D410' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAbUlEQVR4nGNYhQEaGAYTpIn7QgMYWhmmADGSWMAUhqkMIQxTHZDFWhlCGUMYAgJQxBhdGaYwOogguS9q6dKlq6atzJqG5L6AVpFWJHVQMdFQBwwxsFtQ7ZgCFkNxC8jNjKEOKG4eqPCjIsTiPgDvNMzp+eoFHAAAAABJRU5ErkJggg==',
			'9C54' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAbklEQVR4nGNYhQEaGAYTpIn7WAMYQ1lDHRoCkMREprA2ujYwNCKLBbSKNADFWtHFWKcyTAlAct+0qdNWLc3MiopCch+rqwiQDHRA1svQChYLDUESEwDbEYDhFkdHVPeB3MwQyoAiNlDhR0WIxX0AomHOFb2AkJYAAAAASUVORK5CYII=',
			'3FA5' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAaklEQVR4nGNYhQEaGAYTpIn7RANEQx2mMIYGIIkFTBFpYAhldEBR2SrSwOjoiCoGVMfaEOjqgOS+lVFTw5auioyKQnYfWF1AgwiaeayhWMQaAh1E0NwC1BuA7D7RALDYVIdBEH5UhFjcBwCEaMwGhWVi3gAAAABJRU5ErkJggg==',
			'1E84' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAY0lEQVR4nGNYhQEaGAYTpIn7GB1EQxlCGRoCkMRYHUQaGB0dGpHFRIFirA0BrQEoesHqpgQguW9l1tSwVaGroqKQ3AdR5+iArpe1ITA0BEMsoAGLHShioiGYbh6o8KMixOI+AKqQykVVLEU1AAAAAElFTkSuQmCC',
			'63EA' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAaUlEQVR4nGNYhQEaGAYTpIn7WANYQ1hDHVqRxUSmiLSyNjBMdUASC2hhaHRtYAgIQBZrYACqY3QQQXJfZNSqsKWhK7OmIbkvZAqKOojeVpB5jKEhmGIo6iBuQRWDuNkRRWygwo+KEIv7ABBPyyZsZm4PAAAAAElFTkSuQmCC',
			'D528' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAcklEQVR4nGNYhQEaGAYTpIn7QgNEQxlCGaY6IIkFTBFpYHR0CAhAFmsVaWBtCHQQQRULAZIwdWAnRS2dunTVyqypWUjuC2hlaHRoZUAzDyg2hRHdvEaHADSxKaytjA6oekMDGENYQwNQ3DxQ4UdFiMV9ABFTzaSy78RbAAAAAElFTkSuQmCC',
			'7303' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAaUlEQVR4nGNYhQEaGAYTpIn7QkNZQximMIQ6IIu2irQyhDI6BKCIMTQ6Ojo0iCCLTWFoZW0IaAhAdl/UqrClq6KWZiG5j9EBRR0YsjYwNLoCRZDNA7Ix7ACqwHBLQAMWNw9Q+FERYnEfAFwgzHcrZ9FnAAAAAElFTkSuQmCC',
			'3C64' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAZElEQVR4nGNYhQEaGAYTpIn7RAMYQxlCGRoCkMQCprA2Ojo6NCKLMbSKNLg2OLSiiE0RaWAFkgFI7lsZNW3V0qmroqKQ3QdSBzQQ3TzWhsDQEAw7ArC5BUUMm5sHKvyoCLG4DwCs0844cip7agAAAABJRU5ErkJggg==',
			'2A56' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAd0lEQVR4nM2QsQ2AMAwEncI9hdnHFPRGwiNQwBROkQ2AHWBKUjpACQJ/d9K/Tob9cgZ/yit+KCCovLBjNIceDUQck4QJLXDl24liuwQu/NZ1G8ZxmLyfUGTrir3AtWbG5F0s750YZdY0XHRV855C4fzV/x7Mjd8BTsnLznUAY34AAAAASUVORK5CYII=',
			'8341' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAYUlEQVR4nGNYhQEaGAYTpIn7WANYQxgaHVqRxUSmiLQytDpMRRYLaAWqmuoQiqqOoZUhEK4X7KSlUavCVmZmLUV2H0gdK5odIPNcQwMwxBywuQVNDOrm0IBBEH5UhFjcBwCFDs1bTRIttAAAAABJRU5ErkJggg==',
			'9689' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAa0lEQVR4nGNYhQEaGAYTpIn7WAMYQxhCGaY6IImJTGFtZXR0CAhAEgtoFWlkbQh0EEEVa2B0dISJgZ00beq0sFWhq6LCkNzH6ioKMm8qsl4GoHmuDQENyGICEDEUO7C5BZubByr8qAixuA8A8y3LRGpA/k8AAAAASUVORK5CYII=',
			'417E' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAZ0lEQVR4nGNYhQEaGAYTpI37pjAEsIYGhgYgi4UwBjA0BDogq2MMYcUQYwXqZWh0hImBnTRt2qqoVUtXhmYhuS8ApG4KI4re0FCgWACqGMgtjA6YYqwN6GKsoUAxVDcPVPhRD2JxHwB+q8d/+o2yRAAAAABJRU5ErkJggg==',
			'2157' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAb0lEQVR4nGNYhQEaGAYTpIn7WAMYAlhDHUNDkMREpjAGsIJoJLGAVlYMMYZWoN6pQDlk901bFbU0M2tlFrL7gHaATEC2l9EBLDYFxS1AlawNAQHIYkD7AhgdHR2QxUJDWUMZQhlRxAYq/KgIsbgPACvtyLzoCTnmAAAAAElFTkSuQmCC',
			'7B57' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAcklEQVR4nGNYhQEaGAYTpIn7QkNFQ1hDHUNDkEVbRVpZgbQIqlijK7rYFKC6qQwNAcjui5oatjQza2UWkvsYHURagapake1lbRBpdGgImIIsJtIAsiMgAFksoEGkldHR0QFVTDSEIZQRRWygwo+KEIv7AOAiy9OX65SxAAAAAElFTkSuQmCC',
			'E753' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAaUlEQVR4nGNYhQEaGAYTpIn7QkNEQ11DHUIdkMQCGhgaXRsYHQIwxBgaRFDFWlmngmm4+0KjVk1bmpm1NAvJfUD5ABCJah6jA4hENY8VCNHFRBoYHR1R3BIaAlQRyoDi5oEKPypCLO4DAHkXzeR2ZweYAAAAAElFTkSuQmCC',
			'C7DF' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAaUlEQVR4nGNYhQEaGAYTpIn7WENEQ11DGUNDkMREWhkaXRsdHZDVBTQCxRoCUcUaGFpZEWJgJ0WtWjVt6arI0Cwk9wHVBbBi6GV0wBBrZG1AFxNpFWlgRXMLawhQLJQRRWygwo+KEIv7APhRyvaKC/HVAAAAAElFTkSuQmCC',
			'C5DD' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAZklEQVR4nGNYhQEaGAYTpIn7WENEQ1lDGUMdkMREWkUaWBsdHQKQxAIagWINgQ4iyGINIiFIYmAnRa2aunTpqsisaUjuA5rT6IqhF4tYowiGmEgrayu6W1hDGEPQ3TxQ4UdFiMV9AMeFzLdALpqKAAAAAElFTkSuQmCC',
			'D60D' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAYklEQVR4nGNYhQEaGAYTpIn7QgMYQximMIY6IIkFTGFtZQhldAhAFmsVaWR0dHQQQRVrYG0IhImBnRS1dFrY0lWRWdOQ3BfQKtqKpA5unisWMUd0O7C4BZubByr8qAixuA8AlCPMkEza/ogAAAAASUVORK5CYII=',
			'64D1' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAaklEQVR4nGNYhQEaGAYTpIn7WAMYWllDGVqRxUSmMExlbXSYiiwW0MIQytoQEIoi1sDoChSD6QU7KTJq6dKlq6KWIrsvZIpIK5I6iN5W0VBXDDEGDHVAt7QC3YIiBnVzaMAgCD8qQizuAwAbJs0NbEJ2bgAAAABJRU5ErkJggg==',
			'6E37' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAY0lEQVR4nGNYhQEaGAYTpIn7WANEQxmBMARJTGSKSANro0ODCJJYQAuIF4AqBuIB1QUguS8yamrYqqmrVmYhuS9kClhdK7K9Aa1g86ZgEQtAFoO4xdEBi5tRxAYq/KgIsbgPAA+4zKxKrYQnAAAAAElFTkSuQmCC',
			'33D3' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAW0lEQVR4nGNYhQEaGAYTpIn7RANYQ1hDGUIdkMQCpoi0sjY6OgQgq2xlaHRtCGgQQRabwtDKChQLQHLfyqhVYUtXRS3NQnYfqjrc5mERw+YWbG4eqPCjIsTiPgDcZ82ReQOw5wAAAABJRU5ErkJggg==',
			'39D7' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAaElEQVR4nGNYhQEaGAYTpIn7RAMYQ1hDGUNDkMQCprC2sjY6NIggq2wVaXRtCEAVmwIRC0By38qopUtTV0WtzEJ23xTGQKC6VhSbWxlAeqegirGAxAIYMNzi6IDFzShiAxV+VIRY3AcAS9TM044LPGsAAAAASUVORK5CYII=',
			'865E' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAaklEQVR4nGNYhQEaGAYTpIn7WAMYQ1hDHUMDkMREprC2sjYwOiCrC2gVaUQXE5ki0sA6FS4GdtLSqGlhSzMzQ7OQ3CcyRbSVoSEQwzwHLGKuaGIgtzA6OqKIgdzMEMqI4uaBCj8qQizuAwBXMcn9SePKvgAAAABJRU5ErkJggg==',
			'EF54' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAYklEQVR4nGNYhQEaGAYTpIn7QkNEQ11DHRoCkMQCGkQaWBsYGrGItWKITWWYEoDkvtCoqWFLM7OiopDcB1LH0BDogK4XKBYagmFHAIZbGB1R3RcaAtQbyoAiNlDhR0WIxX0Ami/O7G6DUk4AAAAASUVORK5CYII=',
			'5B9E' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAZ0lEQVR4nGNYhQEaGAYTpIn7QkNEQxhCGUMDkMQCGkRaGR0dHRhQxRpdGwJRxAIDRFpZEWJgJ4VNmxq2MjMyNAvZfa0irQwhqHqBYo0OaOYFAMUc0cREpmC6hTUA080DFX5UhFjcBwAswcp3ASD7rwAAAABJRU5ErkJggg==',
			'41A0' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAbElEQVR4nGNYhQEaGAYTpI37pjAEAHErilgIYwBDKMNUByQxxhDWAEZHh4AAJDFWoF7WhkAHEST3TZu2KmrpqsisaUjuC0BVB4ahoUCxUFQxBrC6ABQ7oGIobmGYwhoKFEN180CFH/UgFvcBAGzfylQd9daNAAAAAElFTkSuQmCC',
			'CE3D' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAWklEQVR4nGNYhQEaGAYTpIn7WENEQxmB0AFJTKRVpIG10dEhAEksoFEESAY6iCCLNQB5QHUiSO6LWjU1bNXUlVnTkNyHpg4hhm4eFjuwuQWbmwcq/KgIsbgPAA9YzBnAa15aAAAAAElFTkSuQmCC',
			'6C4A' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAbUlEQVR4nGNYhQEaGAYTpIn7WAMYQxkaHVqRxUSmsAJFHKY6IIkFtIg0AEUCApDFGkQaGAIdHUSQ3BcZNW3VyszMrGlI7guZItLA2ghXB9HbChQLDQwNQRNzQFMHdguaGMTNqGIDFX5UhFjcBwDyXc1x4elroAAAAABJRU5ErkJggg==',
			'D8DB' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAWUlEQVR4nGNYhQEaGAYTpIn7QgMYQ1hDGUMdkMQCprC2sjY6OgQgi7WKNLo2BDqIoIgB1QHFApDcF7V0ZdjSVZGhWUjuQ1OHxzwsYljcgs3NAxV+VIRY3AcAhX3OFD7v5H4AAAAASUVORK5CYII=',
			'8F71' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAXklEQVR4nGNYhQEaGAYTpIn7WANEQ11DA1qRxUSmiADJgKnIYgGtYLFQDHWNDjC9YCctjZoatmopECK5D6xuCkMrhnkBmGKMDgwYbmFtQBVjDQCLhQYMgvCjIsTiPgDHkMx3VqIStgAAAABJRU5ErkJggg==',
			'FD6F' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAVElEQVR4nGNYhQEaGAYTpIn7QkNFQxhCGUNDkMQCGkRaGR0dHRhQxRpdG7CJMcLEwE4KjZq2MnXqytAsJPeB1WE1L5AYMSxuAbsZRWygwo+KEIv7AMJ7y8ywoeElAAAAAElFTkSuQmCC',
			'B6B8' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAXElEQVR4nGNYhQEaGAYTpIn7QgMYQ1hDGaY6IIkFTGFtZW10CAhAFmsVaWRtCHQQQVEn0oCkDuyk0KhpYUtDV03NQnJfwBRRrOa5opuHTQyLW7C5eaDCj4oQi/sA/eTOgb2fFkQAAAAASUVORK5CYII=',
			'05C6' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAcUlEQVR4nGNYhQEaGAYTpIn7GB1EQxlCHaY6IImxBogAxQMCApDERKaINLA2CDoIIIkFtIqEsAJVIrsvaunUpUtXrUzNQnJfQCtDo2sDI4p5UDEHEVQ7gGKCKGKsAayt6G5hdGAMQXfzQIUfFSEW9wEA7wzLQiprzKsAAAAASUVORK5CYII=',
			'5A46' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAdklEQVR4nGNYhQEaGAYTpIn7QkMYAhgaHaY6IIkFNDCGMLQ6BASgiLG2Mkx1dBBAEgsMEGl0CHR0QHZf2LRpKzMzM1OzkN3XKtLo2uiIYh5Dq2ioa2iggwiyHUB1Do2OKGIiU0BiqG5hDQCLobh5oMKPihCL+wDNds2uGPiq5wAAAABJRU5ErkJggg==',
			'C459' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAdklEQVR4nGNYhQEaGAYTpIn7WEMYWllDHaY6IImJtDJMZW1gCAhAEgtoZAhlbWB0EEEWa2B0ZZ0KFwM7KWrV0qVLM7OiwpDcFwAysSFgKqpe0VAHkAyqHa2sDQEodgB1tjI6OqC4BeRmhlAGFDcPVPhREWJxHwC8KsvtEsGCZAAAAABJRU5ErkJggg==',
			'DD31' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAWElEQVR4nGNYhQEaGAYTpIn7QgNEQxhDGVqRxQKmiLSyNjpMRRFrFWl0aAgIxRBrdIDpBTspaum0lVlTVy1Fdh+aOmTzCItB3IIiBnVzaMAgCD8qQizuAwCSbs/Az5DJAwAAAABJRU5ErkJggg==',
			'EE8B' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAATUlEQVR4nGNYhQEaGAYTpIn7QkNEQxlCGUMdkMQCGkQaGB0dHQLQxFgbAh1EcKsDOyk0amrYqtCVoVlI7iPFPAJ24HTzQIUfFSEW9wEAq+LLzvp7xgsAAAAASUVORK5CYII=',
			'2747' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAcElEQVR4nM2QsRGAIAxFQ8EGuE/YIN6ZIWQKKNgA2QGmNHbhsNRTXveK/HdAn16EP/FKn6WFMXnelHMFEmaMTjnK4o7RQRZWjKT7aq9tDy3oPgKyclHvGjRomcrQIsgKaeeuxeRRO+bZffV/D3LTdwKUu8wgxdhDTAAAAABJRU5ErkJggg==',
			'7DF3' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAYUlEQVR4nGNYhQEaGAYTpIn7QkNFQ1hDA0IdkEVbRVpZGxgdAlDFGl2BtAiy2BSIWACy+6KmrUwNXbU0C8l9jA4o6sCQtQHTPBEsYgENmG4JaAC6uYEB1c0DFH5UhFjcBwACXMzqbclFewAAAABJRU5ErkJggg==',
			'0693' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAaUlEQVR4nGNYhQEaGAYTpIn7GB0YQxhCGUIdkMRYA1hbGR0dHQKQxESmiDSyNgQ0iCCJBbSKNIDEApDcF7V0WtjKzKilWUjuC2gVbWUIgauD6W10QDMPZIcjmhg2t2Bz80CFHxUhFvcBAPgezBxCZbgfAAAAAElFTkSuQmCC',
			'5AE6' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAbUlEQVR4nGNYhQEaGAYTpIn7QkMYAlhDHaY6IIkFNDCGsDYwBASgiLG2sjYwOgggiQUGiDS6AsWQ3Rc2bdrK1NCVqVnI7msFq0Mxj6FVNBSkVwTZDog6FDGRKSAxVLewguxFc/NAhR8VIRb3AQDKr8wO592JlQAAAABJRU5ErkJggg==',
			'21C6' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAbElEQVR4nGNYhQEaGAYTpIn7WAMYAhhCHaY6IImJTGEMYHQICAhAEgtoZQ1gbRB0EEDW3coAFGN0QHHftFVRS1etTM1Cdl8AWB2KeUBdYL0iyG5pYADbgSwGZGO4JTSUNRTdzQMVflSEWNwHAMZbyK3+84+VAAAAAElFTkSuQmCC',
			'EF1E' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAUklEQVR4nGNYhQEaGAYTpIn7QkNEQx2mMIYGIIkFNIg0MIQwOjCgiTFiEWOYAhcDOyk0amrYqmkrQ7OQ3IemjmKx0BCgW0IdUdw8UOFHRYjFfQAuZsqjjWzIsQAAAABJRU5ErkJggg==',
			'1BFB' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAXElEQVR4nGNYhQEaGAYTpIn7GB1EQ1hDA0MdkMRYHURaWYEyAUhiog4ija5AMREUvSjqwE5amTU1bGnoytAsJPcxYjGPEbt5hOyAuCUE6OYGRhQ3D1T4URFicR8AIeTIKhXAP+QAAAAASUVORK5CYII=',
			'A405' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAb0lEQVR4nM2QsRGAIAxFPwUb4D5Q0McihUyTJhvACDZMKXYRLfXO/7uXy+Vd0G8R/Kmf+LkIRXVMhnlCA4+JYaEOktKFkbrsZc3R+JV9pG+lGD/SoF5IgtllXjhPjBR63pgZGEQzq2jxB/97sQ9+B63Ry31cv+chAAAAAElFTkSuQmCC',
			'5892' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAd0lEQVR4nGNYhQEaGAYTpIn7QkMYQxhCGaY6IIkFNLC2Mjo6BASgiIk0ujYEOoggiQUGsLaygmSQ3Bc2bWXYysyoVVHI7mtlbWUICWhEtoOhVQTID2hFdksAUMyxIWAKspjIFIhbkMVYA0BuZgwNGQThR0WIxX0A1njMjLjlyNAAAAAASUVORK5CYII=',
			'9ED2' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAZUlEQVR4nGNYhQEaGAYTpIn7WANEQ1lDGaY6IImJTBFpYG10CAhAEgtoBYo1BDqIYIgFNIgguW/a1KlhS1dFASHCfayuYHWNyHYwQPS2IrtFACI2hQGLWzDdzBgaMgjCj4oQi/sA0OfMkcULzdwAAAAASUVORK5CYII=',
			'D79C' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAaklEQVR4nGNYhQEaGAYTpIn7QgNEQx1CGaYGIIkFTGFodHR0CBBBFmtlaHRtCHRgQRVrZQWKIbsvaumqaSszI7OQ3QdUF8AQAlcHFWME8tHFWBsY0e2YItLAiOaWUBAPzc0DFX5UhFjcBwD/GMyvUXEBkgAAAABJRU5ErkJggg==',
			'AF9E' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAYUlEQVR4nGNYhQEaGAYTpIn7GB1EQx1CGUMDkMRYA0QaGB0dHZDViUwRaWBtCEQRC2hFEQM7KWrp1LCVmZGhWUjuA6ljCEHVGxoKFMNiHiM2MTS3gM1Dc/NAhR8VIRb3AQCk+spqcXNrFQAAAABJRU5ErkJggg==',
			'A00B' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAZUlEQVR4nGNYhQEaGAYTpIn7GB0YAhimMIY6IImxBjCGMIQyOgQgiYlMYW1ldHR0EEESC2gVaXRtCISpAzspaum0lamrIkOzkNyHpg4MQ0MhYqjmYbMD0y0BrZhuHqjwoyLE4j4AzsPLYsSfYO4AAAAASUVORK5CYII=',
			'1C72' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAcElEQVR4nGNYhQEaGAYTpIn7GB0YQ1lDA6Y6IImxOrA2OjQEBAQgiYk6iDQ4NAQCSWS9QB5QpQiS+1ZmTVu1aumqVVFI7gOrmwJSiaY3gKGVAU3M0QGoEkWMtdEVpBLZLSFANzcwhoYMgvCjIsTiPgD/X8os1zWkqgAAAABJRU5ErkJggg==',
			'A5D7' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAcUlEQVR4nGNYhQEaGAYTpIn7GB1EQ1lDGUNDkMRYA0QaWBsdGkSQxESmAMUaAlDEAlpFQkBiAUjui1o6denSVVErs5DcF9DK0OgKIpH0hoaCxaYwoJoHEgtAFWNtZW10dEAVYwwBuhlFbKDCj4oQi/sAqpzNd5BZgoQAAAAASUVORK5CYII=',
			'D672' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAbklEQVR4nGNYhQEaGAYTpIn7QgMYQ1hDA6Y6IIkFTGFtBZIBAchirSKNDA2BDiKoYg0MjQ4NIkjui1o6LWzVUiCN5L6AVtFWhikglajmOQQwtDKgiTk6AFWiuYW1gSEAw80NjKEhgyD8qAixuA8AybTOBWjpZkEAAAAASUVORK5CYII=',
			'2AB0' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAb0lEQVR4nGNYhQEaGAYTpIn7WAMYAlhDGVqRxUSmMIawNjpMdUASC2hlbWVtCAgIQNbdKtLo2ujoIILsvmnTVqaGrsyahuy+ABR1YMjoIBrq2hCIIsbaAFSHZocISAzNLaGhQDE0Nw9U+FERYnEfAO4BzRhbbP+IAAAAAElFTkSuQmCC',
			'62BE' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAa0lEQVR4nGNYhQEaGAYTpIn7WAMYQ1hDGUMDkMREprC2sjY6OiCrC2gRaXRtCEQVa2BodEWoAzspMmrV0qWhK0OzkNwXMoVhCoZ5rQwBrOjmtTI6oIsB3dKArpc1QDTUFc3NAxV+VIRY3AcAwxrLBnxlw5EAAAAASUVORK5CYII=',
			'6298' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAc0lEQVR4nGNYhQEaGAYTpIn7WAMYQxhCGaY6IImJTGFtZXR0CAhAEgtoEWl0bQh0EEEWa2AAigXA1IGdFBm1aunKzKipWUjuC5nCMIUhJADVvFaGAAZ081oZHRjRxIBuaUB3C2uAaKgDmpsHKvyoCLG4DwCS7sx3j8/fuAAAAABJRU5ErkJggg==',
			'6E4B' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAaUlEQVR4nGNYhQEaGAYTpIn7WANEQxkaHUMdkMREpog0MLQ6OgQgiQW0AMWmOjqIIIs1AHmBcHVgJ0VGTQ1bmZkZmoXkvhCgeayNaOa1AsVCA1HNA4oB3YIiBnYLml5sbh6o8KMixOI+ADyezEF/P09SAAAAAElFTkSuQmCC',
			'8A37' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAcElEQVR4nGNYhQEaGAYTpIn7WAMYAhhDGUNDkMREpjCGsDY6NIggiQW0srYCSRQxkSkijQ5AdQFI7lsaNW1l1tRVK7OQ3AdV18qAYp5oKFDnFFQxEZBpAQxodrg2Ojqgulmk0TGUEUVsoMKPihCL+wAUoM3HVKQlvgAAAABJRU5ErkJggg==',
			'1FA2' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAaElEQVR4nGNYhQEaGAYTpIn7GB1EQx2mMEx1QBJjdRBpYAhlCAhAEhMFijE6OoJkkPSKNLA2BDSIILlvZdbUsKWrooAQ4T6oukYHdL2hAa0MmOZNwSIWgCwmGgISCwwNGQThR0WIxX0AfbzKOYSXVscAAAAASUVORK5CYII=',
			'A00E' => 'iVBORw0KGgoAAAANSUhEUgAAAEkAAAAhAgMAAADoum54AAAACVBMVEX///8AAADS0tIrj1xmAAAAYklEQVR4nGNYhQEaGAYTpIn7GB0YAhimMIYGIImxBjCGMIQCZZDERKawtjI6OqKIBbSKNLo2BMLEwE6KWjptZeqqyNAsJPehqQPD0FBMsYBWbHZguiWgFdPNAxV+VIRY3AcAHTzKBqlgGAwAAAAASUVORK5CYII='        
        );
        $this->text = array_rand( $images );
        return $images[ $this->text ] ;    
    }
    
    function out_processing_gif(){
        $image = dirname(__FILE__) . '/processing.gif';
        $base64_image = "R0lGODlhFAAUALMIAPh2AP+TMsZiALlcAKNOAOp4ANVqAP+PFv///wAAAAAAAAAAAAAAAAAAAAAAAAAAACH/C05FVFNDQVBFMi4wAwEAAAAh+QQFCgAIACwAAAAAFAAUAAAEUxDJSau9iBDMtebTMEjehgTBJYqkiaLWOlZvGs8WDO6UIPCHw8TnAwWDEuKPcxQml0Ynj2cwYACAS7VqwWItWyuiUJB4s2AxmWxGg9bl6YQtl0cAACH5BAUKAAgALAEAAQASABIAAAROEMkpx6A4W5upENUmEQT2feFIltMJYivbvhnZ3Z1h4FMQIDodz+cL7nDEn5CH8DGZhcLtcMBEoxkqlXKVIgAAibbK9YLBYvLtHH5K0J0IACH5BAUKAAgALAEAAQASABIAAAROEMkphaA4W5upMdUmDQP2feFIltMJYivbvhnZ3V1R4BNBIDodz+cL7nDEn5CH8DGZAMAtEMBEoxkqlXKVIg4HibbK9YLBYvLtHH5K0J0IACH5BAUKAAgALAEAAQASABIAAAROEMkpjaE4W5tpKdUmCQL2feFIltMJYivbvhnZ3R0A4NMwIDodz+cL7nDEn5CH8DGZh8ONQMBEoxkqlXKVIgIBibbK9YLBYvLtHH5K0J0IACH5BAUKAAgALAEAAQASABIAAAROEMkpS6E4W5spANUmGQb2feFIltMJYivbvhnZ3d1x4JMgIDodz+cL7nDEn5CH8DGZgcBtMMBEoxkqlXKVIggEibbK9YLBYvLtHH5K0J0IACH5BAUKAAgALAEAAQASABIAAAROEMkpAaA4W5vpOdUmFQX2feFIltMJYivbvhnZ3V0Q4JNhIDodz+cL7nDEn5CH8DGZBMJNIMBEoxkqlXKVIgYDibbK9YLBYvLtHH5K0J0IACH5BAUKAAgALAEAAQASABIAAAROEMkpz6E4W5tpCNUmAQD2feFIltMJYivbvhnZ3R1B4FNRIDodz+cL7nDEn5CH8DGZg8HNYMBEoxkqlXKVIgQCibbK9YLBYvLtHH5K0J0IACH5BAkKAAgALAEAAQASABIAAAROEMkpQ6A4W5spIdUmHQf2feFIltMJYivbvhnZ3d0w4BMAIDodz+cL7nDEn5CH8DGZAsGtUMBEoxkqlXKVIgwGibbK9YLBYvLtHH5K0J0IADs=";
        $binary = is_file($image) ? join("",file($image)) : base64_decode($base64_image); 
        header("Cache-Control: post-check=0, pre-check=0, max-age=0, no-store, no-cache, must-revalidate");
        header("Pragma: no-cache");
        header("Content-type: image/gif");
        echo $binary;
    }

}
# end of class phpfmgImage
# ------------------------------------------------------
# end of module : captcha


# module user
# ------------------------------------------------------
function phpfmg_user_isLogin(){
    return ( isset($_SESSION['authenticated']) && true === $_SESSION['authenticated'] );
}


function phpfmg_user_logout(){
    session_destroy();
    header("Location: admin.php");
}

function phpfmg_user_login()
{
    if( phpfmg_user_isLogin() ){
        return true ;
    };
    
    $sErr = "" ;
    if( 'Y' == $_POST['formmail_submit'] ){
        if(
            defined( 'PHPFMG_USER' ) && strtolower(PHPFMG_USER) == strtolower($_POST['Username']) &&
            defined( 'PHPFMG_PW' )   && strtolower(PHPFMG_PW) == strtolower($_POST['Password']) 
        ){
             $_SESSION['authenticated'] = true ;
             return true ;
             
        }else{
            $sErr = 'Login failed. Please try again.';
        }
    };
    
    // show login form 
    phpfmg_admin_header();
?>
<form name="frmFormMail" action="" method='post' enctype='multipart/form-data'>
<input type='hidden' name='formmail_submit' value='Y'>
<br><br><br>

<center>
<div style="width:380px;height:260px;">
<fieldset style="padding:18px;" >
<table cellspacing='3' cellpadding='3' border='0' >
	<tr>
		<td class="form_field" valign='top' align='right'>Email :</td>
		<td class="form_text">
            <input type="text" name="Username"  value="<?php echo $_POST['Username']; ?>" class='text_box' >
		</td>
	</tr>

	<tr>
		<td class="form_field" valign='top' align='right'>Password :</td>
		<td class="form_text">
            <input type="password" name="Password"  value="" class='text_box'>
		</td>
	</tr>

	<tr><td colspan=3 align='center'>
        <input type='submit' value='Login'><br><br>
        <?php if( $sErr ) echo "<span style='color:red;font-weight:bold;'>{$sErr}</span><br><br>\n"; ?>
        <a href="admin.php?mod=mail&func=request_password">I forgot my password</a>   
    </td></tr>
</table>
</fieldset>
</div>
<script type="text/javascript">
    document.frmFormMail.Username.focus();
</script>
</form>
<?php
    phpfmg_admin_footer();
}


function phpfmg_mail_request_password(){
    $sErr = '';
    if( $_POST['formmail_submit'] == 'Y' ){
        if( strtoupper(trim($_POST['Username'])) == strtoupper(trim(PHPFMG_USER)) ){
            phpfmg_mail_password();
            exit;
        }else{
            $sErr = "Failed to verify your email.";
        };
    };
    
    $n1 = strpos(PHPFMG_USER,'@');
    $n2 = strrpos(PHPFMG_USER,'.');
    $email = substr(PHPFMG_USER,0,1) . str_repeat('*',$n1-1) . 
            '@' . substr(PHPFMG_USER,$n1+1,1) . str_repeat('*',$n2-$n1-2) . 
            '.' . substr(PHPFMG_USER,$n2+1,1) . str_repeat('*',strlen(PHPFMG_USER)-$n2-2) ;


    phpfmg_admin_header("Request Password of Email Form Admin Panel");
?>
<form name="frmRequestPassword" action="admin.php?mod=mail&func=request_password" method='post' enctype='multipart/form-data'>
<input type='hidden' name='formmail_submit' value='Y'>
<br><br><br>

<center>
<div style="width:580px;height:260px;text-align:left;">
<fieldset style="padding:18px;" >
<legend>Request Password</legend>
Enter Email Address <b><?php echo strtoupper($email) ;?></b>:<br />
<input type="text" name="Username"  value="<?php echo $_POST['Username']; ?>" style="width:380px;">
<input type='submit' value='Verify'><br>
The password will be sent to this email address. 
<?php if( $sErr ) echo "<br /><br /><span style='color:red;font-weight:bold;'>{$sErr}</span><br><br>\n"; ?>
</fieldset>
</div>
<script type="text/javascript">
    document.frmRequestPassword.Username.focus();
</script>
</form>
<?php
    phpfmg_admin_footer();    
}


function phpfmg_mail_password(){
    phpfmg_admin_header();
    if( defined( 'PHPFMG_USER' ) && defined( 'PHPFMG_PW' ) ){
        $body = "Here is the password for your form admin panel:\n\nUsername: " . PHPFMG_USER . "\nPassword: " . PHPFMG_PW . "\n\n" ;
        if( 'html' == PHPFMG_MAIL_TYPE )
            $body = nl2br($body);
        mailAttachments( PHPFMG_USER, "Password for Your Form Admin Panel", $body, PHPFMG_USER, 'You', "You <" . PHPFMG_USER . ">" );
        echo "<center>Your password has been sent.<br><br><a href='admin.php'>Click here to login again</a></center>";
    };   
    phpfmg_admin_footer();
}


function phpfmg_writable_check(){
 
    if( is_writable( dirname(PHPFMG_SAVE_FILE) ) && is_writable( dirname(PHPFMG_EMAILS_LOGFILE) )  ){
        return ;
    };
?>
<style type="text/css">
    .fmg_warning{
        background-color: #F4F6E5;
        border: 1px dashed #ff0000;
        padding: 16px;
        color : black;
        margin: 10px;
        line-height: 180%;
        width:80%;
    }
    
    .fmg_warning_title{
        font-weight: bold;
    }

</style>
<br><br>
<div class="fmg_warning">
    <div class="fmg_warning_title">Your form data or email traffic log is NOT saving.</div>
    The form data (<?php echo PHPFMG_SAVE_FILE ?>) and email traffic log (<?php echo PHPFMG_EMAILS_LOGFILE?>) will be created automatically when the form is submitted. 
    However, the script doesn't have writable permission to create those files. In order to save your valuable information, please set the directory to writable.
     If you don't know how to do it, please ask for help from your web Administrator or Technical Support of your hosting company.   
</div>
<br><br>
<?php
}


function phpfmg_log_view(){
    $n = isset($_REQUEST['file'])  ? $_REQUEST['file']  : '';
    $files = array(
        1 => PHPFMG_EMAILS_LOGFILE,
        2 => PHPFMG_SAVE_FILE,
    );
    
    phpfmg_admin_header();
   
    $file = $files[$n];
    if( is_file($file) ){
        if( 1== $n ){
            echo "<pre>\n";
            echo join("",file($file) );
            echo "</pre>\n";
        }else{
            $man = new phpfmgDataManager();
            $man->displayRecords();
        };
     

    }else{
        echo "<b>No form data found.</b>";
    };
    phpfmg_admin_footer();
}


function phpfmg_log_download(){
    $n = isset($_REQUEST['file'])  ? $_REQUEST['file']  : '';
    $files = array(
        1 => PHPFMG_EMAILS_LOGFILE,
        2 => PHPFMG_SAVE_FILE,
    );

    $file = $files[$n];
    if( is_file($file) ){
        phpfmg_util_download( $file, PHPFMG_SAVE_FILE == $file ? 'form-data.csv' : 'email-traffics.txt', true, 1 ); // skip the first line
    }else{
        phpfmg_admin_header();
        echo "<b>No email traffic log found.</b>";
        phpfmg_admin_footer();
    };

}


function phpfmg_log_delete(){
    $n = isset($_REQUEST['file'])  ? $_REQUEST['file']  : '';
    $files = array(
        1 => PHPFMG_EMAILS_LOGFILE,
        2 => PHPFMG_SAVE_FILE,
    );
    phpfmg_admin_header();

    $file = $files[$n];
    if( is_file($file) ){
        echo unlink($file) ? "It has been deleted!" : "Failed to delete!" ;
    };
    phpfmg_admin_footer();
}


function phpfmg_util_download($file, $filename='', $toCSV = false, $skipN = 0 ){
    if (!is_file($file)) return false ;

    set_time_limit(0);


    $buffer = "";
    $i = 0 ;
    $fp = @fopen($file, 'rb');
    while( !feof($fp)) { 
        $i ++ ;
        $line = fgets($fp);
        if($i > $skipN){ // skip lines
            if( $toCSV ){ 
              $line = str_replace( chr(0x09), ',', $line );
              $buffer .= phpfmg_data2record( $line, false );
            }else{
                $buffer .= $line;
            };
        }; 
    }; 
    fclose ($fp);
  

    
    /*
        If the Content-Length is NOT THE SAME SIZE as the real conent output, Windows+IIS might be hung!!
    */
    $len = strlen($buffer);
    $filename = basename( '' == $filename ? $file : $filename );
    $file_extension = strtolower(substr(strrchr($filename,"."),1));

    switch( $file_extension ) {
        case "pdf": $ctype="application/pdf"; break;
        case "exe": $ctype="application/octet-stream"; break;
        case "zip": $ctype="application/zip"; break;
        case "doc": $ctype="application/msword"; break;
        case "xls": $ctype="application/vnd.ms-excel"; break;
        case "ppt": $ctype="application/vnd.ms-powerpoint"; break;
        case "gif": $ctype="image/gif"; break;
        case "png": $ctype="image/png"; break;
        case "jpeg":
        case "jpg": $ctype="image/jpg"; break;
        case "mp3": $ctype="audio/mpeg"; break;
        case "wav": $ctype="audio/x-wav"; break;
        case "mpeg":
        case "mpg":
        case "mpe": $ctype="video/mpeg"; break;
        case "mov": $ctype="video/quicktime"; break;
        case "avi": $ctype="video/x-msvideo"; break;
        //The following are for extensions that shouldn't be downloaded (sensitive stuff, like php files)
        case "php":
        case "htm":
        case "html": 
                $ctype="text/plain"; break;
        default: 
            $ctype="application/x-download";
    }
                                            

    //Begin writing headers
    header("Pragma: public");
    header("Expires: 0");
    header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
    header("Cache-Control: public"); 
    header("Content-Description: File Transfer");
    //Use the switch-generated Content-Type
    header("Content-Type: $ctype");
    //Force the download
    header("Content-Disposition: attachment; filename=".$filename.";" );
    header("Content-Transfer-Encoding: binary");
    header("Content-Length: ".$len);
    
    while (@ob_end_clean()); // no output buffering !
    flush();
    echo $buffer ;
    
    return true;
 
    
}
?>